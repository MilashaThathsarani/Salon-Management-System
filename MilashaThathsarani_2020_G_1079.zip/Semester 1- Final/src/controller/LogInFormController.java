package controller;

import com.jfoenix.controls.JFXButton;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class LogInFormController {
    public TextField txtUserName;
    public TextField txtPassword;
    public AnchorPane logInContext;
    public JFXButton userOnAction;


    public void logInOnAction(ActionEvent actionEvent) throws IOException {
       if (txtUserName.getText().equalsIgnoreCase("Admin") && txtPassword.getText().equalsIgnoreCase("1234")) {
            Stage window = (Stage) logInContext.getScene().getWindow();
            window.setScene(new Scene(FXMLLoader.load(getClass().getResource("../view/DashBoardAdmin.fxml"))));
            window.centerOnScreen();

        }
        if (txtUserName.getText().equalsIgnoreCase("Cashier") && txtPassword.getText().equalsIgnoreCase("6789")) {
            Stage window = (Stage) logInContext.getScene().getWindow();
            window.setScene(new Scene(FXMLLoader.load(getClass().getResource("../view/DashBoardCashier.fxml"))));
            window.centerOnScreen();
        }

        /*String userName = txtUserName.getText();
        String password = new String(Base64.getEncoder().encode(txtPassword.getText().getBytes()));


        LogInFormController logIn = new LogInFormController().getUser(userName,password);

        if (logIn!=null){
            if (logIn.getRole().equals("ADMIN")){
                AnchorPane pane;
                FXMLLoader fxmlLoader = new FXMLLoader(this.getClass().getResource("../view/DashBoardAdmin.fxml"));
                pane = fxmlLoader.load();
                logInContext.getChildren().setAll(pane);
            }else if (logIn.getRole().equals("RECEPTION")){
                AnchorPane pane;
                FXMLLoader fxmlLoader = new FXMLLoader(this.getClass().getResource("../view/DashBoardCashier.fxml"));
                pane = fxmlLoader.load();
                logInContext.getChildren().setAll(pane);
            }else {
                new Alert(Alert.AlertType.WARNING,"Invalid User Name or Password.");
                txtPassword.clear();
                txtUserName.clear();
            }
        }*/
    }

    public void getRole(){

    }
    public void moveOnAction(ActionEvent actionEvent) {
        txtPassword.requestFocus();
    }

    public void UserOnAction(ActionEvent actionEvent) throws IOException {
        Stage window = (Stage) logInContext.getScene().getWindow();
        window.setScene(new Scene(FXMLLoader.load(getClass().getResource("../view/User.fxml"))));
        window.centerOnScreen();
    }
}


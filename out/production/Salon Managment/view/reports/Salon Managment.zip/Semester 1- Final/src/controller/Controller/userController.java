package controller.Controller;

import db.DbConnection;
import interfaces.UserInterface;
import model.Client;
import model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class userController implements UserInterface {
    @Override
    public boolean saveUser(User u1) throws SQLException, ClassNotFoundException {
        Connection con= DbConnection.getInstance().getConnection();
        String query="INSERT INTO Users VALUES(md5(?), ?, ?, md5(?), ?)";
        PreparedStatement stm = con.prepareStatement(query);
        stm.setObject(1,u1.getUserName());
        stm.setObject(2,u1.getFullName());
        stm.setObject(3,u1.getEmail());
        stm.setObject(4,u1.getPassword());
        stm.setObject(5,u1.getRollType());

        return stm.executeUpdate()>0;
    }

    @Override
    public boolean updateClient(User u) throws SQLException, ClassNotFoundException {
        return false;
    }
}
